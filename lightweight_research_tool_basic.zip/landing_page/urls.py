from django.urls import path

from landing_page.views import *

urlpatterns = [
    path('', landing_page, name='landing_page'),
]
