from django.apps import AppConfig


class LandingPageConfig(AppConfig):
    name = 'landing_page'
