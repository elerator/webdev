import datetime
from django.db import models

# books/models.py
class ResearchProject(models.Model):
    title = models.CharField(max_length=1000)
    short_title = models.CharField(max_length=1000)
    project_partner = models.CharField(max_length=1000)
    goal = models.CharField(max_length=1000)
    milestones = models.CharField(max_length=1000)
    short_description = models.CharField(max_length=1000)
    plant_name = models.CharField(max_length=1000)
    funding = models.CharField(max_length=1000)
    tools = models.CharField(max_length=1000)
    budget = models.PositiveIntegerField()
    leader = models.CharField(max_length=1000)
    start = models.DateField()
    end = models.DateField()
    cost_center = models.CharField(max_length=1000)

    def __str__(self):
        return self.title
