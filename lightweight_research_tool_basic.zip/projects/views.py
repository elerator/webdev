from django.shortcuts import render
from django.views.generic import CreateView
from django import forms
from django.forms import ModelForm, Textarea

from django.urls import reverse_lazy

from django.http import HttpResponseRedirect, HttpResponse

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Fieldset, ButtonHolder, Submit
from crispy_forms.layout import Div

from .models import ResearchProject
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.views.generic import ListView
from django.core import serializers

from django.views.generic import UpdateView
from django.views.generic.edit import DeleteView


# https://www.agiliq.com/blog/2019/01/django-createview/
# https://simpleisbetterthancomplex.com/tutorial/2018/08/13/how-to-use-bootstrap-4-forms-with-django.html
# Display primary key https://stackoverflow.com/questions/5666505/how-to-subclass-djangos-generic-createview-with-initial-data

def projects(request, pk):
    return HttpResponseRedirect(reverse_lazy("projects:project-list"))

public_labels = {#attributes and their respective labels that can be seen by any authentificated user. Budget etc are ommitted here.
    "title": "Project Title",
    "short_title" : "Project short Title ",
    "project_partner" : "Originator(s) and project partners ",
    "goal" : "Goal and motivation",
    "milestones" : "Milestones and targeted outcome/transfer",
    "short_description" : "Short work description",
    "plant_name" : "Plant or process name",
    "funding" : "Funding source / customer",
    "tools" : "Methods and tools",
}

private_labels = {}#We can use the customly generated labels (e.g. Buget for key "buget"), hence the dict is empty

labels = {**public_labels, **private_labels}

class ProjectList(ListView):
    model = ResearchProject
    template_name = 'projects/list.html'
    context_object_name = 'projects'
    paginate_by = 8#This many items go on each page

    def get_context_data(self, **kwargs):
        """ Defines the context that is rendered as a list. Retrieves all projects from the database and
            returns all columns that correspond to public_labels keys. These columns are redered as the view.
            Pagination is used. Items are split such that this.paginate_by items are on each page.
        """
        context = super(ProjectList, self).get_context_data(**kwargs)
        projects = self.model.objects.all()

        page = self.request.GET.get('page')
        paginator = Paginator(list(projects), self.paginate_by)#the paginator splits the projects (a list of dicts) into pages with this.paginate_by items on each page

        try:
            projects = paginator.page(page)
        except PageNotAnInteger:
            projects = paginator.page(1)
        except EmptyPage:
            projects = paginator.page(paginator.num_pages)

        context['projects'] = serializers.serialize( "python", projects, fields = public_labels.keys())
        context["columns"] = public_labels.values
        return context

class ProjectLetterAdapter(forms.ModelForm):
    """ Makes Model accessible for use in child classes of CreateView. """
    short_title = forms.CharField(required=False)
    class Meta:
        model = ResearchProject
        fields = ["title","short_title","project_partner","goal","milestones","short_description","plant_name",
                    "funding","tools","budget","leader","start","end","cost_center"]
        labels = labels

        widgets = {
            'start': forms.TextInput(attrs={'type': 'date'}),#set the type of of the input fields
            'end': forms.TextInput(attrs={'type': 'date'})
        }

class ProjectLetter(CreateView):
    def get_initial(self, *args, **kwargs):
        """ Defines default values for the input form """
        initial = super(ProjectLetter, self).get_initial(**kwargs)
        #initial['title'] = 'My Title'
        return initial

    def get(self, request, *args, **kwargs):
        form_helper = ProjectLetterAdapter()
        context = {'project_letter': form_helper, "mode":"Create"}
        return render(request, 'projects/create.html', context)

    def post(self, request, *args, **kwargs):
        form = ProjectLetterAdapter(request.POST)
        if form.is_valid():
            item = form.save()
            item.save()
            return HttpResponseRedirect(reverse_lazy('projects:detail', args=[item.id]))
        return render(request, 'projects/create.html', {'project_letter': form, "mode":"create"})

class ProjectEdit(UpdateView):
    def get(self, request, *args, **kwargs):
        proj = ResearchProject.objects.get(pk=kwargs["pk"])
        form_helper = ProjectLetterAdapter(instance=proj)
        context = {'project_letter': form_helper, "mode":"Update", "pk":proj}
        return render(request, 'projects/create.html', context)

    def post(self, request, *args, **kwargs):
        pk = self.kwargs["pk"]
        original = ResearchProject.objects.get(pk=pk)
        form = ProjectLetterAdapter(request.POST, instance= original)
        if form.is_valid():
            updated = form.save()
            updated.save()
            return HttpResponseRedirect(reverse_lazy('projects:detail', args=[0]))
        return render(request, 'projects/create.html', {'project_letter_main': form})

class EntryDelete(DeleteView):
    template_name = 'projects/delete.html'
    model = ResearchProject
    success_url = reverse_lazy('projects:project-list', args=[])
