from django.urls import path

from . import views
from .views import *


app_name = 'projects'
urlpatterns = [
    path('create/', views.ProjectLetter.as_view(), name='create'),
    path('<int:pk>/', projects, name='detail'),
    path('list/', views.ProjectList.as_view(), name='project-list'),
    path('update/<int:pk>/', views.ProjectEdit.as_view(), name='update'),
    path('delete/<int:pk>/', views.EntryDelete.as_view(), name='entry_delete'),
]
